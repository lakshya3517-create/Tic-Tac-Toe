#!/usr/bin/env bash
# Automated checks for tictactoe.c: feeds scripted moves and checks the output.
set -u
BIN=./tictactoe
pass=0; fail=0

check() {  # check "name" "input" "expected text"
  local name="$1" input="$2" expect="$3" out
  out=$(printf "$input" | "$BIN" 2>&1)
  if grep -qF -- "$expect" <<<"$out"; then
    echo "PASS: $name"; pass=$((pass+1))
  else
    echo "FAIL: $name (expected: $expect)"; fail=$((fail+1))
  fi
}

# X wins top row: X1 O4 X2 O5 X3
check "X wins on a row"        '1\n4\n2\n5\n3\nn\n'            "Player 1 (X) wins"
# O wins middle column: X1 O2 X3 O5 X4 O8
check "O wins on a column"     '1\n2\n3\n5\n4\n8\nn\n'          "Player 2 (O) wins"
# X wins main diagonal: X1 O2 X5 O3 X9
check "X wins on a diagonal"   '1\n2\n5\n3\n9\nn\n'            "Player 1 (X) wins"
# X wins anti-diagonal: X3 O1 X5 O2 X7
check "X wins on anti-diagonal" '3\n1\n5\n2\n7\nn\n'           "Player 1 (X) wins"
# Draw: X1 O2 X3 O5 X4 O6 X8 O7 X9
check "Draw detected"          '1\n2\n3\n5\n4\n6\n8\n7\n9\nn\n' "It's a draw"
# Bad input then valid game
check "Rejects text input"     'abc\n1\n4\n2\n5\n3\nn\n'        "Please enter a number"
check "Rejects out of range"   '0\n10\n1\n4\n2\n5\n3\nn\n'      "between 1 and 9"
check "Rejects taken cell"     '1\n1\n4\n2\n5\n3\nn\n'          "already taken"
# Play again: X wins, then replay and X wins again, score shows 2
check "Play again and scores"  '1\n4\n2\n5\n3\ny\n1\n4\n2\n5\n3\nn\n' "Player 1 (X): 2"

# Closed input must exit cleanly instead of looping forever
if printf '' | timeout 5 "$BIN" >/dev/null 2>&1; then
  echo "PASS: Exits cleanly on closed input"; pass=$((pass+1))
else
  echo "FAIL: Hangs or crashes on closed input"; fail=$((fail+1))
fi

echo "Passed: $pass  Failed: $fail"
[ "$fail" -eq 0 ]
